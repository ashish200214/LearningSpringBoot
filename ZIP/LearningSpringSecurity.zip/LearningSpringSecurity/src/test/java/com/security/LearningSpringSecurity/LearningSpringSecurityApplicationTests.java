package com.security.LearningSpringSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
